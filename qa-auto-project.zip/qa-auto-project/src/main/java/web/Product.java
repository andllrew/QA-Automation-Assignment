package web;

public class Product {
    private String name;
    private int id;
    private double price;
    private long quantity;
    
    public Product(String name, int id, double price, long quantity) {
        this.name = name;
        this.id = id;
        this.price = price;
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public double getPrice() {
        return price;
    }

    public long getQuantity() {
        return quantity;
    }

    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }

    public double getTotalValue() {
        return quantity * price;
    }

    @Override
    public String toString() {
        return "Product {" +
                "name='" + name + ",\'" +
                "id=" + id + ",\'" +
                "price=" + price + ",\'" +
                "quantity=" + quantity + "\'" +
                "}";
    }

}
