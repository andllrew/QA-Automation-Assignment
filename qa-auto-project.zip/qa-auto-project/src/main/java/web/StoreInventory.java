package web;

import java.util.ArrayList;
import java.util.List;

public class StoreInventory {
    private List<Product> inventory;

    public StoreInventory() {
        this.inventory = new ArrayList<>();
    }

    public void addProduct(Product product) {
        inventory.add(product);
    }

    public void removeProduct(int id) {
        for (Product product : inventory) {
            if (product.getId() == id) {
                inventory.remove(product);
                break;
            }
        }
    }

    public void updateProductQuantity(long quantity, int id) {
        for (Product product : inventory) {
            if (product.getId() == id) {
                product.setQuantity(quantity);
                break;
            }
        }
    }

    public List<Product> getInventory() {
        return inventory;
    }

    public void viewInventory() {
        for (Product product : inventory) {
            System.out.println(product);
        }
    }

    public double calculateInventoryTotalValue() {
        double total = 0;
        for (Product product : inventory) {
            total += product.getTotalValue();
        }

        return total;
    }

    public void displayInventoryTotalValue() {
        System.out.println("Total value of inventory: " + calculateInventoryTotalValue());
    }

}
