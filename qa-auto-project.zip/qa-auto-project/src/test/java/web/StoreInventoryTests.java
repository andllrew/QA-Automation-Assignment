package web;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class StoreInventoryTests {
    public static String TEST_NAME_1 = "Peanuts";
    public static int TEST_ID_1 = 102;
    public static double TEST_PRICE_1 = 2.50;
    public static long TEST_QUANTITY_1 = 146;

    public static String TEST_NAME_2 = "Chips";
    public static int TEST_ID_2 = 223;
    public static double TEST_PRICE_2 = 1.25;
    public static long TEST_QUANTITY_2 = 582;

    public static double TEST_TOTAL = 1092.5;

    private StoreInventory storeInventory;
    private Product product_1;
    private Product product_2;

    @Before
    public void setUp() {
        storeInventory = new StoreInventory();
        product_1 = new Product(TEST_NAME_1, TEST_ID_1, TEST_PRICE_1, TEST_QUANTITY_1);
        product_2 = new Product(TEST_NAME_2, TEST_ID_2, TEST_PRICE_2, TEST_QUANTITY_2);
    }

    @Test
    public void store_inventory_starts_with_0_products() {
        assertTrue(storeInventory.getInventory().isEmpty());
    }

    @Test
    public void store_inventory_increase_1_after_product_added() {
        long initialInventorySize = storeInventory.getInventory().size();
        storeInventory.addProduct(product_1);
        long finalInventorySize = storeInventory.getInventory().size();
        assertEquals(initialInventorySize + 1, finalInventorySize);
    }

    @Test
    public void store_inventory_increase_2_after_products_added() {
        long initialInventorySize = storeInventory.getInventory().size();
        storeInventory.addProduct(product_1);
        storeInventory.addProduct(product_2);
        long finalInventorySize = storeInventory.getInventory().size();
        assertEquals(initialInventorySize + 2, finalInventorySize);
    }

    @Test
    public void store_inventory_decrease_1_after_product_removed() {
        storeInventory.addProduct(product_1);
        long initialInventorySize = storeInventory.getInventory().size();
        storeInventory.removeProduct(product_1.getId());
        long finalInventorySize = storeInventory.getInventory().size();
        assertEquals(initialInventorySize - 1, finalInventorySize);
    }

    @Test
    public void store_inventory_decrease_2_after_products_removed() {
        storeInventory.addProduct(product_1);
        storeInventory.addProduct(product_2);
        long initialInventorySize = storeInventory.getInventory().size();
        storeInventory.removeProduct(product_1.getId());
        storeInventory.removeProduct(product_2.getId());
        long finalInventorySize = storeInventory.getInventory().size();
        assertEquals(initialInventorySize - 2, finalInventorySize);
    }

    @Test
    public void product_1_quantity_updated() {
        product_1.setQuantity(TEST_QUANTITY_1 + 100);
        assertEquals(product_1.getQuantity(), TEST_QUANTITY_1 + 100);
    }

    @Test
    public void product_2_quantity_updated() {
        product_2.setQuantity(TEST_QUANTITY_2 + 500);
        assertEquals(product_2.getQuantity(), TEST_QUANTITY_2 + 500);
    }

    @Test
    public void display_current_inventory() {
        storeInventory.addProduct(product_1);
        List<Product> productList = storeInventory.getInventory();
        assertEquals(productList.get(0).toString(), 
        "Product {" +
        "name='" + product_1.getName() + ",\'" +
        "id=" + product_1.getId() + ",\'" +
        "price=" + product_1.getPrice() + ",\'" +
        "quantity=" + product_1.getQuantity() + "\'" +
        "}");
    }

    @Test
    public void store_inventory_calculated_total() {
        storeInventory.addProduct(product_1);
        storeInventory.addProduct(product_2);
        double finalInventoryTotal = storeInventory.calculateInventoryTotalValue();
        assertEquals(finalInventoryTotal, TEST_TOTAL, 0);
    }

}
